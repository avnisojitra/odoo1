{

	'name' : 'estate',
	'application' : True,
	'category' : 'sales',
	'data' : [
		'security/ir.model.access.csv',
		'views/estate_menus.xml',
		
	],
}

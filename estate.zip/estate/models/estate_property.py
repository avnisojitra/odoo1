from odoo import fields,models

class EstateProperty(models.Model):
	_name = "estate.property"
	_description = "Estate Property"
	
	name = fields.Char(required=True, string="property name", defualt="unkonwn")
	description = fields.Text()
	postcode = fields.Char()
	date_avaliability = fields.Date(defualt=lambda self: fields.datatime.now(), copy=False)
	expected_price = fields.Float(required=True)
	selling_price = fields.Float(copy=False, readonly=True)
	bedrooms = fields.Integer(defualt=2)
	living_area = fields.Integer()
	facades = fields.Integer()
	garage = fields.Boolean()
	garden = fields.Boolean()
	garden_area = fields.Integer()
	garden_orientation = fields.Selection([
		('North' , 'North'),
		('South' , 'South'),
		('East' , 'East'),
		('West' , 'West')
	])
	
